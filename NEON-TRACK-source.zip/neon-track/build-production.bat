@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install Node.js 20 LTS or newer, then run this file again.
  pause
  exit /b 1
)
if not exist node_modules (
  call npm install
  if errorlevel 1 goto :failed
)
call npm run build
if errorlevel 1 goto :failed
echo Production build created in the dist folder.
pause
exit /b 0
:failed
echo Build failed. Read the errors above.
pause
exit /b 1
