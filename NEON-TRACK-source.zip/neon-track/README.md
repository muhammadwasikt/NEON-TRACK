# NEON TRACK

A standalone browser-based 3D endless runner built with React, Vite and Three.js. It is independent of Base44 and does not require an account, server, paid API or runtime internet connection.

## Run locally

Requirements: Node.js 20.19+ or 22.12+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. To create and preview a production build:

```bash
npm run build
npm run preview
```

## Controls

| Action | Keyboard | Touch |
|---|---|---|
| Change lane | A / D or ← / → | Swipe left / right or on-screen arrows |
| Jump | W / ↑ / Space | Swipe up or on-screen up button |
| Slide | S / ↓ | Swipe down or on-screen down button |
| Pause | Escape | Pause button |

## Included systems

- Three-lane 3D endless runner with a procedural futuristic rail-city environment.
- Original articulated runner with run, jump and slide animation.
- Barriers, crates, overhead beams and trains with jump/slide/lane collision rules.
- Rotating coin pickups, collection particles and four power-ups: magnet, shield, double-score and speed boost.
- Progressive speed, changing environment palettes, score and distance tracking.
- Three selectable characters, local coin wallet, upgrades, missions and browser-local save persistence.
- Tutorial, main menu, gameplay HUD, pause, game-over, settings, graphics quality controls and optional procedural audio.
- Desktop keyboard, mobile swipe and touch-button controls.

## Save data

Progress is saved in browser `localStorage` under `neon-track-save-v1`. Clearing browser site data removes local progress.

## Notes

The railway, city, runner, obstacles, coins and power-up objects are procedurally generated with Three.js geometry and materials. The project uses no Subway Surfers characters, branding, maps or assets. All game logic, fonts and visuals use local code and browser/system resources after installation; gameplay does not fetch external APIs or assets.

## Windows quick start

1. Install Node.js 20 LTS or newer.
2. Extract the ZIP to a normal folder (not inside the ZIP preview).
3. Double-click `start-neon-track.bat`. On first run it installs the project dependencies, then starts the local game server.
4. Open the local address Vite prints in the terminal (normally `http://localhost:5173`). Keep the terminal open while playing.

`build-production.bat` installs dependencies if needed and creates an optimized production build in `dist/`.
