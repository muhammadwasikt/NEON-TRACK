export class AudioEngine {
  constructor() {
    this.context = null;
    this.enabled = true;
    this.musicEnabled = false;
    this.musicNodes = [];
  }

  ensureContext() {
    if (typeof window === 'undefined') return null;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return null;
    if (!this.context) this.context = new AudioContext();
    if (this.context.state === 'suspended') this.context.resume().catch(() => {});
    return this.context;
  }

  setEffects(enabled) { this.enabled = enabled; }

  tone(startFrequency, endFrequency, duration, type = 'sine', volume = 0.065) {
    if (!this.enabled) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(startFrequency, ctx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(35, endFrequency), ctx.currentTime + duration);
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(volume, ctx.currentTime + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.start();
    oscillator.stop(ctx.currentTime + duration + 0.025);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }

  play(name) {
    const sounds = {
      coin: [920, 1450, 0.085, 'sine', 0.045],
      jump: [260, 520, 0.13, 'triangle', 0.05],
      slide: [210, 95, 0.16, 'sawtooth', 0.035],
      power: [420, 1050, 0.24, 'sine', 0.055],
      crash: [150, 42, 0.42, 'sawtooth', 0.07],
      shield: [620, 210, 0.2, 'triangle', 0.06],
      click: [440, 590, 0.055, 'sine', 0.025],
      mission: [660, 990, 0.22, 'triangle', 0.05],
    };
    const sound = sounds[name];
    if (sound) this.tone(...sound);
  }

  setMusic(enabled) {
    this.musicEnabled = enabled;
    if (!enabled && this.musicNodes.length === 0) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    if (enabled && this.musicNodes.length === 0) {
      const master = ctx.createGain();
      master.gain.value = 0.012;
      master.connect(ctx.destination);
      [55, 82.41, 110].forEach((frequency, index) => {
        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        oscillator.type = index === 1 ? 'triangle' : 'sine';
        oscillator.frequency.value = frequency;
        gain.gain.value = index === 0 ? 0.34 : 0.12;
        oscillator.connect(gain);
        gain.connect(master);
        oscillator.start();
        this.musicNodes.push(oscillator, gain);
      });
      this.musicNodes.push(master);
    } else if (!enabled && this.musicNodes.length) {
      const oscillators = this.musicNodes.filter((node) => node instanceof OscillatorNode);
      oscillators.forEach((oscillator) => { try { oscillator.stop(); oscillator.disconnect(); } catch {} });
      this.musicNodes.filter((node) => !(node instanceof OscillatorNode)).forEach((node) => { try { node.disconnect(); } catch {} });
      this.musicNodes = [];
    }
  }

  dispose() { this.setMusic(false); this.context?.close().catch(() => {}); this.context = null; }
}
