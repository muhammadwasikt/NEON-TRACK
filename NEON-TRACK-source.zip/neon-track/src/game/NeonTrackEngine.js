import * as THREE from 'three';

const LANES = [-2.4, 0, 2.4];
const PLAYER_Z = 5.2;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const choose = (items) => items[Math.floor(Math.random() * items.length)];

const THEMES = [
  { name: 'NEON METRO CITY', background: '#07111f', fog: '#07111f', glow: '#00d9ff', secondary: '#ff4fa2' },
  { name: 'INDUSTRIAL RAILWAY', background: '#17131a', fog: '#1b171d', glow: '#ff994d', secondary: '#ffd166' },
  { name: 'FUTURISTIC DOWNTOWN', background: '#071b20', fog: '#0a2027', glow: '#53f0c2', secondary: '#39b8ff' },
  { name: 'UNDERGROUND TUNNEL', background: '#090d1b', fog: '#0b1020', glow: '#ad8aff', secondary: '#00d9ff' },
  { name: 'ELEVATED SKYLINE', background: '#101827', fog: '#13283d', glow: '#ff5aab', secondary: '#f3ce68' },
];

export class NeonTrackEngine {
  constructor(canvas, callbacks = {}) {
    this.canvas = canvas;
    this.callbacks = callbacks;
    this.disposed = false;
    this.frameId = 0;
    this.lastFrame = 0;
    this.elapsed = 0;
    this.worldTime = 0;
    this.mode = 'menu';
    this.paused = false;
    this.quality = 'auto';
    this.activeObjects = [];
    this.objectPools = new Map();
    this.particles = [];
    this.themeIndex = 0;
    this.lane = 1;
    this.targetLane = 1;
    this.jumpHeight = 0;
    this.jumpVelocity = 0;
    this.slideTimer = 0;
    this.magnetTimer = 0;
    this.multiplierTimer = 0;
    this.boostTimer = 0;
    this.shieldCharges = 0;
    this.distance = 0;
    this.score = 0;
    this.runCoins = 0;
    this.speed = 15;
    this.spawnTimer = 1.0;
    this.lastHudUpdate = 0;
    this.options = { quality: 'auto', character: 0, upgrades: { magnet: 0, shield: 0, multiplier: 0 } };
    this.tick = this.tick.bind(this);
    this.handleResize = this.handleResize.bind(this);
  }

  init() {
    const width = Math.max(1, this.canvas.clientWidth);
    const height = Math.max(1, this.canvas.clientHeight);
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: this.quality !== 'low',
      alpha: false,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(this.getPixelRatio());
    this.renderer.setSize(width, height, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.22;
    this.renderer.shadowMap.enabled = this.quality === 'high';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(THEMES[0].background);
    this.scene.fog = new THREE.FogExp2(THEMES[0].fog, 0.0082);
    this.camera = new THREE.PerspectiveCamera(57, width / height, 0.1, 280);
    this.camera.position.set(0, 6.2, 13.5);
    this.camera.lookAt(0, 1.0, -12);

    this.createLighting();
    this.createTrack();
    this.createCity();
    this.createStationInfrastructure();
    this.createWorldVariants();
    this.createPlayer();
    this.clock = new THREE.Clock();

    window.addEventListener('resize', this.handleResize, { passive: true });
    this.lastFrame = performance.now();
    this.frameId = requestAnimationFrame(this.tick);
  }

  getPixelRatio() {
    const deviceRatio = window.devicePixelRatio || 1;
    const widthCap = window.innerWidth < 700 ? 1.15 : 1.6;
    if (this.quality === 'low') return Math.min(0.9, deviceRatio);
    if (this.quality === 'medium') return Math.min(1.25, deviceRatio);
    if (this.quality === 'high') return Math.min(1.8, deviceRatio);
    return Math.min(widthCap, deviceRatio);
  }

  setOptions(options = {}) {
    const oldQuality = this.quality;
    this.options = { ...this.options, ...options, upgrades: { ...this.options.upgrades, ...(options.upgrades || {}) } };
    this.quality = this.options.quality || 'auto';
    if (this.renderer && oldQuality !== this.quality) {
      this.renderer.setPixelRatio(this.getPixelRatio());
      this.renderer.setSize(this.canvas.clientWidth || 1, this.canvas.clientHeight || 1, false);
      this.renderer.shadowMap.enabled = this.quality === 'high';
      this.scene?.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = this.quality === 'high';
          child.receiveShadow = this.quality === 'high';
        }
      });
    }
    if (this.player) this.applyCharacterLook(this.options.character || 0);
  }

  makeMaterial(color, options = {}) {
    return new THREE.MeshStandardMaterial({
      color,
      roughness: options.roughness ?? 0.62,
      metalness: options.metalness ?? 0.12,
      emissive: options.emissive || '#000000',
      emissiveIntensity: options.emissiveIntensity ?? 0.5,
    });
  }

  addBox(parent, width, height, depth, color, x, y, z, options = {}) {
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(width, height, depth),
      options.material || this.makeMaterial(color, options),
    );
    mesh.position.set(x, y, z);
    mesh.castShadow = this.quality === 'high';
    mesh.receiveShadow = this.quality === 'high';
    parent.add(mesh);
    return mesh;
  }

  createLighting() {
    this.scene.add(new THREE.HemisphereLight('#b6dcff', '#141827', 1.45));
    const sun = new THREE.DirectionalLight('#fff0d3', 2.15);
    sun.position.set(-8, 16, 9);
    sun.castShadow = this.quality === 'high';
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -16;
    sun.shadow.camera.right = 16;
    sun.shadow.camera.top = 20;
    sun.shadow.camera.bottom = -20;
    this.scene.add(sun);
    const cyan = new THREE.PointLight('#00d9ff', 24, 60, 2);
    cyan.position.set(-8, 5, -14);
    const pink = new THREE.PointLight('#ff4fa2', 19, 50, 2);
    pink.position.set(8, 4, -37);
    this.scene.add(cyan, pink);
    this.accentLights = [cyan, pink];
  }

  createTrack() {
    this.addBox(this.scene, 9.8, 0.28, 250, '#111b2a', 0, -0.2, -94, { roughness: 0.94 });
    this.addBox(this.scene, 150, 0.12, 270, '#080f19', 0, -0.43, -95, { roughness: 1 });

    for (const laneX of LANES) {
      this.addBox(this.scene, 1.5, 0.05, 250, '#202d3e', laneX, -0.03, -94, { roughness: 0.9 });
      for (const offset of [-0.58, 0.58]) {
        this.addBox(this.scene, 0.13, 0.17, 250, '#a5bacb', laneX + offset, 0.08, -94, { metalness: 0.78, roughness: 0.3 });
      }
    }

    this.sleepers = [];
    for (let i = 0; i < 84; i += 1) {
      this.sleepers.push(this.addBox(this.scene, 8.2, 0.15, 0.42, '#293b4c', 0, -0.02, -216 + i * 2.75, { roughness: 0.95 }));
    }
    this.edgeLights = [
      this.addBox(this.scene, 0.06, 0.06, 250, '#00d9ff', -4.9, 0.03, -94, { emissive: '#00d9ff', emissiveIntensity: 3 }),
      this.addBox(this.scene, 0.06, 0.06, 250, '#ff4fa2', 4.9, 0.03, -94, { emissive: '#ff4fa2', emissiveIntensity: 3 }),
    ];
  }

  createCity() {
    this.cityChunks = [];
    const facades = ['#17263a', '#1b2c43', '#20243b', '#1a3039', '#24243b', '#172f42'];
    const windowMaterials = [
      this.makeMaterial('#ffcb74', { emissive: '#ffb84e', emissiveIntensity: 1.25, roughness: 0.4 }),
      this.makeMaterial('#5eeaff', { emissive: '#00c8f0', emissiveIntensity: 1.2, roughness: 0.4 }),
      this.makeMaterial('#ff76bd', { emissive: '#ef3e9b', emissiveIntensity: 1.1, roughness: 0.4 }),
    ];
    for (let index = 0; index < 11; index += 1) {
      const chunk = new THREE.Group();
      chunk.position.z = -155 + index * 23;
      for (const side of [-1, 1]) {
        const width = 4.4 + Math.random() * 3.2;
        const height = 13 + Math.random() * 23;
        const x = side * (8.6 + width * 0.35);
        this.addBox(chunk, width, height, 9 + Math.random() * 4, choose(facades), x, height / 2 - 0.35, 0, { roughness: 0.88 });
        const rows = Math.floor(height / 2.7);
        for (let row = 0; row < rows; row += 1) {
          for (let column = 0; column < 2; column += 1) {
            if (Math.random() < 0.28) continue;
            const window = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.68, 0.06), choose(windowMaterials));
            window.position.set(x + (column - 0.5) * 1.42, 1.3 + row * 2.55, side * -0.16);
            chunk.add(window);
          }
        }
        if (Math.random() > 0.2) {
          const signColor = side < 0 ? '#00d9ff' : '#ff4fa2';
          const sign = this.addBox(chunk, 2.6, 1.25, 0.18, signColor, x - side * 1.4, 4.2 + Math.random() * 2, 0.18, { emissive: signColor, emissiveIntensity: 2.1, roughness: 0.32 });
          sign.rotation.y = side < 0 ? 0.06 : -0.06;
        }
        if (Math.random() > 0.4) {
          this.addBox(chunk, width + 0.55, 0.16, 9.4, '#52687d', x, height - 0.2, 0, { metalness: 0.48 });
        }
      }
      if (index % 2 === 0) this.addSkyBridge(chunk);
      this.scene.add(chunk);
      this.cityChunks.push(chunk);
    }
  }

  addSkyBridge(parent) {
    const bridge = new THREE.Group();
    this.addBox(bridge, 0.32, 5.4, 0.5, '#34465b', -5.45, 2.65, 0);
    this.addBox(bridge, 0.32, 5.4, 0.5, '#34465b', 5.45, 2.65, 0);
    this.addBox(bridge, 11.4, 0.35, 0.55, '#40566c', 0, 5.2, 0);
    this.addBox(bridge, 10.7, 0.055, 0.12, '#00d9ff', 0, 5.0, 0.28, { emissive: '#00d9ff', emissiveIntensity: 2.8 });
    parent.add(bridge);
  }

  createStationInfrastructure() {
    this.stationFrames = [];
    for (let i = 0; i < 9; i += 1) {
      const frame = new THREE.Group();
      this.addBox(frame, 0.24, 7, 0.28, '#34485d', -6.2, 3.4, 0);
      this.addBox(frame, 0.24, 7, 0.28, '#34485d', 6.2, 3.4, 0);
      this.addBox(frame, 12.5, 0.16, 0.28, '#435c70', 0, 6.85, 0);
      const lampLeft = new THREE.PointLight('#66eaff', 7, 17, 2);
      lampLeft.position.set(-4.4, 6.5, 0);
      const lampRight = new THREE.PointLight('#ff58b3', 6, 16, 2);
      lampRight.position.set(4.4, 6.5, 0);
      frame.add(lampLeft, lampRight);
      frame.position.z = -125 + i * 29;
      this.scene.add(frame);
      this.stationFrames.push(frame);
    }
  }


  createWorldVariants() {
    this.tunnelSections = [];
    this.industrialSections = [];
    this.elevatedSections = [];

    for (let index = 0; index < 7; index += 1) {
      const tunnel = new THREE.Group();
      this.addBox(tunnel, 13.1, 0.35, 48, '#182638', 0, 7.2, 0, { roughness: 0.9 });
      this.addBox(tunnel, 0.28, 7.2, 48, '#25364b', -6.35, 3.45, 0, { roughness: 0.82 });
      this.addBox(tunnel, 0.28, 7.2, 48, '#25364b', 6.35, 3.45, 0, { roughness: 0.82 });
      for (const z of [-20, -7, 7, 20]) {
        this.addBox(tunnel, 0.18, 7.0, 0.2, '#52627b', -6.1, 3.45, z, { metalness: 0.48 });
        this.addBox(tunnel, 0.18, 7.0, 0.2, '#52627b', 6.1, 3.45, z, { metalness: 0.48 });
        this.addBox(tunnel, 12.2, 0.18, 0.2, '#52627b', 0, 6.9, z, { metalness: 0.48 });
      }
      this.addBox(tunnel, 0.07, 0.08, 48, '#00d9ff', -5.95, 6.15, 0, { emissive: '#00d9ff', emissiveIntensity: 2.5 });
      this.addBox(tunnel, 0.07, 0.08, 48, '#ff4fa2', 5.95, 6.15, 0, { emissive: '#ff4fa2', emissiveIntensity: 2.2 });
      for (const z of [-15, 0, 15]) {
        this.addBox(tunnel, 1.8, 0.08, 1.1, '#d9f8ff', 0, 6.93, z, { emissive: '#8cecff', emissiveIntensity: 2.7 });
      }
      tunnel.position.z = -180 + index * 48;
      tunnel.visible = false;
      this.scene.add(tunnel);
      this.tunnelSections.push(tunnel);

      const industrial = new THREE.Group();
      for (const side of [-1, 1]) {
        const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.19, 48, 12), this.makeMaterial('#677584', { roughness: 0.38, metalness: 0.84 }));
        pipe.rotation.x = Math.PI / 2;
        pipe.position.set(side * 7.3, 4.5, 0);
        industrial.add(pipe);
        this.addBox(industrial, 0.3, 5.8, 0.35, '#465360', side * 7.25, 2.85, -19, { metalness: 0.55 });
        this.addBox(industrial, 0.3, 5.8, 0.35, '#465360', side * 7.25, 2.85, 19, { metalness: 0.55 });
        this.addBox(industrial, 0.55, 0.5, 4.2, '#7c5037', side * 9.3, 0.1, -12, { metalness: 0.25, roughness: 0.86 });
        this.addBox(industrial, 0.55, 0.5, 4.2, '#7c5037', side * 9.3, 0.1, 13, { metalness: 0.25, roughness: 0.86 });
      }
      this.addBox(industrial, 0.18, 5.8, 0.25, '#805b44', -5.8, 2.9, 0);
      this.addBox(industrial, 0.18, 5.8, 0.25, '#805b44', 5.8, 2.9, 0);
      industrial.position.z = -180 + index * 48;
      industrial.visible = false;
      this.scene.add(industrial);
      this.industrialSections.push(industrial);

      const elevated = new THREE.Group();
      for (const side of [-1, 1]) {
        this.addBox(elevated, 0.48, 8.2, 0.55, '#334b62', side * 6.6, 4.0, -18, { metalness: 0.3 });
        this.addBox(elevated, 0.48, 8.2, 0.55, '#334b62', side * 6.6, 4.0, 18, { metalness: 0.3 });
        this.addBox(elevated, 0.16, 0.16, 48, '#9db6c8', side * 6.6, 7.8, 0, { metalness: 0.8, roughness: 0.25 });
      }
      this.addBox(elevated, 13.7, 0.2, 0.5, '#566f83', 0, 7.35, 0, { metalness: 0.45 });
      this.addBox(elevated, 0.08, 0.08, 48, '#ff5aab', 0, 7.22, 0, { emissive: '#ff5aab', emissiveIntensity: 2.4 });
      elevated.position.z = -180 + index * 48;
      elevated.visible = false;
      this.scene.add(elevated);
      this.elevatedSections.push(elevated);
    }
  }

  createPlayer() {
    this.player = new THREE.Group();
    this.player.position.set(0, 0, PLAYER_Z);
    this.scene.add(this.player);

    this.characterPivot = new THREE.Group();
    this.characterPivot.position.y = 1.0;
    this.player.add(this.characterPivot);

    this.torsoMaterial = this.makeMaterial('#ff7845', { roughness: 0.48, metalness: 0.1, emissive: '#a52a16', emissiveIntensity: 0.18 });
    this.torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.38, 0.72, 5, 12), this.torsoMaterial);
    this.torso.position.y = 0.03;
    this.torso.castShadow = true;
    this.characterPivot.add(this.torso);
    this.jacketStripe = this.addBox(this.characterPivot, 0.11, 0.73, 0.42, '#00d9ff', 0.02, 0.04, 0.36, { emissive: '#00d9ff', emissiveIntensity: 1.5 });

    this.head = new THREE.Mesh(new THREE.SphereGeometry(0.31, 22, 18), this.makeMaterial('#c88c6c', { roughness: 0.7 }));
    this.head.position.y = 0.79;
    this.characterPivot.add(this.head);
    this.hair = new THREE.Mesh(new THREE.SphereGeometry(0.326, 22, 15, 0, Math.PI * 2, 0, Math.PI * 0.57), this.makeMaterial('#1a202a', { roughness: 0.92 }));
    this.hair.position.set(0, 0.87, -0.02);
    this.characterPivot.add(this.hair);
    this.backpack = this.addBox(this.characterPivot, 0.54, 0.63, 0.28, '#1d3047', 0, 0.02, -0.39, { roughness: 0.55, metalness: 0.16 });
    this.addBox(this.characterPivot, 0.07, 0.48, 0.065, '#00d9ff', 0, 0.03, -0.55, { emissive: '#00d9ff', emissiveIntensity: 1.7 });

    this.armPivots = [];
    for (const side of [-1, 1]) {
      const arm = new THREE.Group();
      arm.position.set(side * 0.44, 0.35, 0);
      this.characterPivot.add(arm);
      const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.4, 4, 8), this.makeMaterial('#f09a73'));
      upper.position.y = -0.17;
      upper.rotation.z = side * -0.12;
      arm.add(upper);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 10), this.makeMaterial('#c88c6c'));
      hand.position.y = -0.43;
      arm.add(hand);
      this.armPivots.push(arm);
    }

    this.legPivots = [];
    for (const side of [-1, 1]) {
      const leg = new THREE.Group();
      leg.position.set(side * 0.2, -0.34, 0);
      this.characterPivot.add(leg);
      const pants = new THREE.Mesh(new THREE.CapsuleGeometry(0.15, 0.44, 4, 9), this.makeMaterial('#203d63', { roughness: 0.72 }));
      pants.position.y = -0.27;
      leg.add(pants);
      const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.17, 0.48), this.makeMaterial('#edf5ff', { roughness: 0.42 }));
      shoe.position.set(0, -0.55, 0.13);
      leg.add(shoe);
      const sole = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.05, 0.49), this.makeMaterial('#00d9ff', { emissive: '#00d9ff', emissiveIntensity: 1.8 }));
      sole.position.set(0, -0.64, 0.13);
      leg.add(sole);
      this.legPivots.push(leg);
    }

    this.playerShadow = new THREE.Mesh(new THREE.CircleGeometry(0.72, 28), new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.27 }));
    this.playerShadow.rotation.x = -Math.PI / 2;
    this.playerShadow.position.set(0, -0.055, 0.04);
    this.scene.add(this.playerShadow);
    this.applyCharacterLook(this.options.character || 0);
  }

  applyCharacterLook(character) {
    const looks = [
      { body: '#ff7845', stripe: '#00d9ff', pack: '#1d3047', hair: '#1a202a' },
      { body: '#41cce9', stripe: '#ff69b4', pack: '#173c55', hair: '#202b3c' },
      { body: '#a48bff', stripe: '#ffd36d', pack: '#322657', hair: '#d7dbea' },
    ];
    const look = looks[character] || looks[0];
    if (this.torsoMaterial) this.torsoMaterial.color.set(look.body);
    if (this.jacketStripe?.material) {
      this.jacketStripe.material.color.set(look.stripe);
      this.jacketStripe.material.emissive.set(look.stripe);
    }
    if (this.backpack?.material) this.backpack.material.color.set(look.pack);
    if (this.hair?.material) this.hair.material.color.set(look.hair);
  }

  handleResize() {
    if (!this.renderer || !this.camera) return;
    const width = Math.max(1, this.canvas.clientWidth);
    const height = Math.max(1, this.canvas.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
    this.renderer.setPixelRatio(this.getPixelRatio());
  }

  startNewRun() {
    this.clearRunObjects();
    this.mode = 'playing';
    this.paused = false;
    this.elapsed = 0;
    this.distance = 0;
    this.score = 0;
    this.runCoins = 0;
    this.speed = 15;
    this.spawnTimer = 0.7;
    this.lane = 1;
    this.targetLane = 1;
    this.jumpHeight = 0;
    this.jumpVelocity = 0;
    this.slideTimer = 0;
    this.magnetTimer = 0;
    this.multiplierTimer = 0;
    this.boostTimer = 0;
    this.shieldCharges = Math.min(3, this.options.upgrades?.shield || 0);
    this.player.position.set(0, 0, PLAYER_Z);
    this.player.rotation.set(0, 0, 0);
    this.characterPivot.rotation.set(0, 0, 0);
    this.characterPivot.position.y = 1.0;
    this.characterPivot.scale.set(1, 1, 1);
    this.spawnWave(true);
    this.callbacks.onHud?.(this.getHud());
  }

  clearRunObjects() {
    for (const object of this.activeObjects) this.recycleGroup(object.group);
    this.activeObjects.length = 0;
    for (const particle of this.particles) {
      this.scene?.remove(particle.mesh);
      particle.mesh.geometry.dispose();
      particle.mesh.material.dispose();
    }
    this.particles.length = 0;
  }

  showMenu() {
    this.clearRunObjects();
    this.mode = 'menu';
    this.paused = false;
    this.jumpHeight = 0;
    this.jumpVelocity = 0;
    this.slideTimer = 0;
    this.magnetTimer = 0;
    this.multiplierTimer = 0;
    this.boostTimer = 0;
    this.shieldCharges = 0;
    this.lane = 1;
    this.targetLane = 1;
    this.player.position.set(0, 0, PLAYER_Z);
    this.player.rotation.set(0, 0, 0);
    this.characterPivot.position.y = 1.0;
    this.characterPivot.rotation.set(0, 0, 0);
    this.characterPivot.scale.set(1, 1, 1);
    this.themeIndex = 0;
    const theme = THEMES[0];
    this.scene.background.set(theme.background);
    this.scene.fog.color.set(theme.fog);
    this.scene.fog.density = 0.0082;
    this.tunnelSections.forEach((section) => { section.visible = false; });
    this.industrialSections.forEach((section) => { section.visible = false; });
    this.elevatedSections.forEach((section) => { section.visible = false; });
    this.accentLights[0].color.set(theme.glow);
    this.accentLights[1].color.set(theme.secondary);
    this.edgeLights[0].material.color.set(theme.glow);
    this.edgeLights[0].material.emissive.set(theme.glow);
    this.edgeLights[1].material.color.set(theme.secondary);
    this.edgeLights[1].material.emissive.set(theme.secondary);
    this.callbacks.onTheme?.(theme.name);
  }

  removeGroup(group) {
    if (!group || !this.scene) return;
    this.scene.remove(group);
    group.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        const materials = Array.isArray(child.material) ? child.material : [child.material];
        materials.forEach((material) => material.dispose());
      }
    });
  }

  acquireGroup(poolKey, build) {
    const pool = this.objectPools.get(poolKey) || [];
    const group = pool.pop() || new THREE.Group();
    if (!group.userData.built) {
      build(group);
      group.userData.built = true;
    }
    group.userData.poolKey = poolKey;
    group.visible = true;
    group.position.set(0, 0, 0);
    group.rotation.set(0, 0, 0);
    group.scale.set(1, 1, 1);
    this.scene.add(group);
    return group;
  }

  recycleGroup(group) {
    if (!group || !this.scene) return;
    this.scene.remove(group);
    group.visible = false;
    const poolKey = group.userData.poolKey;
    if (!poolKey) {
      this.removeGroup(group);
      return;
    }
    if (!this.objectPools.has(poolKey)) this.objectPools.set(poolKey, []);
    this.objectPools.get(poolKey).push(group);
  }

  moveLane(direction) {
    if (this.mode !== 'playing' || this.paused) return;
    this.targetLane = clamp(this.targetLane + direction, 0, 2);
  }

  jump() {
    if (this.mode !== 'playing' || this.paused || this.jumpHeight > 0.04 || this.slideTimer > 0) return;
    this.jumpVelocity = 10.7;
    this.callbacks.onSound?.('jump');
  }

  slide() {
    if (this.mode !== 'playing' || this.paused || this.jumpHeight > 0.05) return;
    this.slideTimer = 0.84;
    this.callbacks.onSound?.('slide');
  }

  pause() { if (this.mode === 'playing') this.paused = true; }
  resume() { if (this.mode === 'playing') { this.paused = false; this.lastFrame = performance.now(); } }

  spawnWave(initial = false) {
    const blockedLane = Math.floor(Math.random() * 3);
    const addSecond = this.distance > 100 && Math.random() > 0.72;
    let secondLane = -1;
    if (addSecond) secondLane = (blockedLane + (Math.random() > 0.5 ? 1 : 2)) % 3;
    const types = this.distance < 100 ? ['barrier', 'crate'] : ['barrier', 'crate', 'beam', 'train'];
    const firstType = choose(types);
    this.spawnObstacle(firstType, blockedLane, -75);
    // Obstacles in one wave share a row: one lane always remains open, and the next row has enough spacing.
    if (secondLane >= 0) this.spawnObstacle(choose(['beam', 'barrier', 'crate']), secondLane, -75);
    const safeLane = [0, 1, 2].find((lane) => lane !== blockedLane && lane !== secondLane);
    this.spawnCoinPattern(safeLane ?? ((blockedLane + 1) % 3), -48, Math.random() > 0.7 ? 'arc' : 'line');
    if (!initial && this.distance > 65 && Math.random() > 0.82) {
      this.spawnPowerup(choose(['magnet', 'shield', 'multiplier', 'boost']), Math.floor(Math.random() * 3), -89);
    }
  }

  spawnObstacle(type, lane, z) {
    const group = this.acquireGroup(`obstacle:${type}`, (newGroup) => {
      if (type === 'barrier' || type === 'crate') {
        const width = type === 'crate' ? 1.12 : 1.36;
        const height = type === 'crate' ? 1.1 : 0.96;
        this.addBox(newGroup, width, height, 0.62, type === 'crate' ? '#b66c3b' : '#f36a4b', 0, height / 2, 0, { roughness: 0.58 });
        this.addBox(newGroup, width + 0.08, 0.12, 0.67, '#fff0d5', 0, height * 0.67, 0, { emissive: '#ff7a43', emissiveIntensity: 0.42 });
        if (type === 'barrier') {
          this.addBox(newGroup, 0.13, 1.26, 0.16, '#4a5f72', -0.48, 0.53, 0);
          this.addBox(newGroup, 0.13, 1.26, 0.16, '#4a5f72', 0.48, 0.53, 0);
        }
      } else if (type === 'beam') {
        this.addBox(newGroup, 1.95, 0.27, 0.42, '#ffbd4f', 0, 1.53, 0, { emissive: '#ff8d2e', emissiveIntensity: 0.66 });
        this.addBox(newGroup, 0.09, 0.22, 0.43, '#fff2d2', -0.56, 1.53, 0);
        this.addBox(newGroup, 0.09, 0.22, 0.43, '#fff2d2', 0.56, 1.53, 0);
        this.addBox(newGroup, 0.1, 1.42, 0.1, '#65798b', -0.9, 0.7, 0);
        this.addBox(newGroup, 0.1, 1.42, 0.1, '#65798b', 0.9, 0.7, 0);
      } else {
        this.addBox(newGroup, 1.95, 3.5, 7.5, '#29435a', 0, 1.75, 0, { metalness: 0.62, roughness: 0.34 });
        this.addBox(newGroup, 2.0, 0.25, 7.55, '#00d9ff', 0, 3.15, 0, { emissive: '#00d9ff', emissiveIntensity: 2.1 });
        for (let index = 0; index < 3; index += 1) {
          this.addBox(newGroup, 0.4, 0.88, 0.07, '#9ddcf1', -0.62 + index * 0.62, 2.2, 3.79, { emissive: '#2788a8', emissiveIntensity: 0.5 });
        }
        this.addBox(newGroup, 1.35, 0.13, 0.18, '#ffb74d', 0, 0.22, 3.82, { emissive: '#ff9e2f', emissiveIntensity: 1.2 });
      }
    });
    group.position.set(LANES[lane], 0, z);
    this.activeObjects.push({ kind: 'obstacle', type, lane, z, group });
  }

  spawnCoinPattern(lane, startZ, pattern) {
    const count = pattern === 'arc' ? 7 : 6;
    for (let index = 0; index < count; index += 1) {
      const group = this.acquireGroup('coin', (newGroup) => {
        const coin = new THREE.Mesh(
          new THREE.CylinderGeometry(0.34, 0.34, 0.105, 24),
          this.makeMaterial('#ffc94d', { roughness: 0.22, metalness: 0.88, emissive: '#ff9c25', emissiveIntensity: 1.2 }),
        );
        coin.rotation.x = Math.PI / 2;
        newGroup.add(coin);
        const rim = new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.035, 7, 24), this.makeMaterial('#fff1ad', { roughness: 0.2, metalness: 0.7, emissive: '#fff0b2', emissiveIntensity: 1.15 }));
        newGroup.add(rim);
      });
      const arc = pattern === 'arc' ? Math.sin((index / (count - 1)) * Math.PI) * 0.92 : 0;
      group.position.set(LANES[lane], 1.05 + arc, startZ - index * 3.55);
      this.activeObjects.push({ kind: 'coin', lane, z: startZ - index * 3.55, group, spin: Math.random() * Math.PI * 2 });
    }
  }

  spawnPowerup(type, lane, z) {
    const colors = { magnet: '#00d9ff', shield: '#6dffac', multiplier: '#bc91ff', boost: '#ff744e' };
    const color = colors[type];
    const group = this.acquireGroup(`powerup:${type}`, (newGroup) => {
      newGroup.add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.43, 1), this.makeMaterial(color, { roughness: 0.22, metalness: 0.42, emissive: color, emissiveIntensity: 1.7 })));
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.06, 9, 32), this.makeMaterial(color, { roughness: 0.2, metalness: 0.55, emissive: color, emissiveIntensity: 2.2 }));
      ring.rotation.x = 0.6;
      newGroup.add(ring);
    });
    group.position.set(LANES[lane], 1.35, z);
    this.activeObjects.push({ kind: 'powerup', type, lane, z, group, spin: Math.random() * 4 });
  }

  makeParticles(position, color, amount = 10) {
    const count = this.quality === 'low' ? Math.max(3, Math.floor(amount / 2)) : amount;
    for (let index = 0; index < count; index += 1) {
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.035 + Math.random() * 0.055, 7, 6),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95 }),
      );
      mesh.position.copy(position);
      this.scene.add(mesh);
      this.particles.push({
        mesh,
        velocity: new THREE.Vector3((Math.random() - 0.5) * 4.8, Math.random() * 4.5, (Math.random() - 0.5) * 4.5),
        life: 0.42 + Math.random() * 0.38,
        maxLife: 0.8,
      });
    }
  }

  collectObject(object, index) {
    const point = object.group.position.clone();
    if (object.kind === 'coin') {
      this.runCoins += 1;
      this.callbacks.onSound?.('coin');
      this.makeParticles(point, '#ffd66f', 8);
    } else {
      const level = this.options.upgrades?.[object.type] || 0;
      if (object.type === 'magnet') this.magnetTimer = 9 + level * 2;
      if (object.type === 'shield') this.shieldCharges = Math.min(2, this.shieldCharges + 1);
      if (object.type === 'multiplier') this.multiplierTimer = 12 + level * 2;
      if (object.type === 'boost') this.boostTimer = 4.5;
      const colors = { magnet: '#00d9ff', shield: '#6dffac', multiplier: '#bc91ff', boost: '#ff744e' };
      this.callbacks.onSound?.('power');
      this.makeParticles(point, colors[object.type], 18);
    }
    this.recycleGroup(object.group);
    this.activeObjects.splice(index, 1);
  }

  handleCollision() {
    if (this.shieldCharges > 0) {
      this.shieldCharges -= 1;
      this.callbacks.onSound?.('shield');
      this.makeParticles(this.player.position.clone().add(new THREE.Vector3(0, 1.2, 0)), '#70ffad', 25);
      return false;
    }
    this.mode = 'over';
    this.gameOverTime = 0;
    this.paused = false;
    this.callbacks.onSound?.('crash');
    this.callbacks.onGameOver?.({ score: Math.floor(this.score), distance: Math.floor(this.distance), coins: this.runCoins });
    return true;
  }

  getHud() {
    return {
      score: Math.floor(this.score),
      distance: Math.floor(this.distance),
      coins: this.runCoins,
      speed: Math.round(this.speed),
      powerups: {
        magnet: this.magnetTimer,
        shield: this.shieldCharges,
        multiplier: this.multiplierTimer,
        boost: this.boostTimer,
      },
      active: this.magnetTimer > 0 ? 'MAGNET' : this.multiplierTimer > 0 ? '2X SCORE' : this.boostTimer > 0 ? 'SPEED BOOST' : this.shieldCharges > 0 ? 'SHIELD' : '',
      theme: THEMES[this.themeIndex].name,
    };
  }

  updateWorld(delta) {
    const movement = this.speed * delta;
    this.sleepers.forEach((sleeper) => {
      sleeper.position.z += movement;
      if (sleeper.position.z > 18) sleeper.position.z -= 231;
    });
    this.cityChunks.forEach((chunk) => {
      chunk.position.z += movement;
      if (chunk.position.z > 31) chunk.position.z -= 253;
    });
    this.stationFrames.forEach((frame) => {
      frame.position.z += movement;
      if (frame.position.z > 22) frame.position.z -= 261;
    });
    [this.tunnelSections, this.industrialSections, this.elevatedSections].forEach((sections) => {
      sections.forEach((section) => {
        section.position.z += movement;
        if (section.position.z > 30) section.position.z -= sections.length * 48;
      });
    });
  }

  updateTheme() {
    const nextIndex = Math.floor(this.distance / 245) % THEMES.length;
    if (nextIndex === this.themeIndex) return;
    this.themeIndex = nextIndex;
    const theme = THEMES[nextIndex];
    this.scene.background.set(theme.background);
    this.scene.fog.color.set(theme.fog);
    this.scene.fog.density = nextIndex === 3 ? 0.018 : nextIndex === 1 ? 0.0068 : 0.0082;
    this.tunnelSections.forEach((section) => { section.visible = nextIndex === 3; });
    this.industrialSections.forEach((section) => { section.visible = nextIndex === 1; });
    this.elevatedSections.forEach((section) => { section.visible = nextIndex === 4; });
    this.accentLights[0].color.set(theme.glow);
    this.accentLights[1].color.set(theme.secondary);
    this.edgeLights[0].material.color.set(theme.glow);
    this.edgeLights[0].material.emissive.set(theme.glow);
    this.edgeLights[1].material.color.set(theme.secondary);
    this.edgeLights[1].material.emissive.set(theme.secondary);
    this.callbacks.onTheme?.(theme.name);
  }

  updatePlayer(delta) {
    const targetX = LANES[this.targetLane];
    const smoothing = Math.min(1, delta * 13.5);
    this.lane += (this.targetLane - this.lane) * smoothing;
    this.player.position.x += (targetX - this.player.position.x) * smoothing;

    if (this.jumpVelocity !== 0 || this.jumpHeight > 0) {
      this.jumpHeight += this.jumpVelocity * delta;
      this.jumpVelocity -= 25 * delta;
      if (this.jumpHeight <= 0) {
        this.jumpHeight = 0;
        this.jumpVelocity = 0;
      }
    }
    if (this.slideTimer > 0) this.slideTimer = Math.max(0, this.slideTimer - delta);
    this.player.position.y = this.jumpHeight;

    const isRunning = this.jumpHeight === 0 && this.slideTimer === 0;
    const bob = isRunning ? Math.sin(this.elapsed * 15.5) * 0.065 : 0;
    this.characterPivot.position.y = this.slideTimer > 0 ? 0.58 : 1.0 + bob;
    this.characterPivot.scale.y = this.slideTimer > 0 ? 0.58 : 1;
    this.characterPivot.rotation.x = this.slideTimer > 0 ? -0.35 : 0;
    const swing = isRunning ? Math.sin(this.elapsed * 15.5) * 0.67 : this.jumpHeight > 0 ? -0.18 : 0;
    this.legPivots[0].rotation.x = swing;
    this.legPivots[1].rotation.x = -swing;
    this.armPivots[0].rotation.x = -swing * 0.72 - 0.12;
    this.armPivots[1].rotation.x = swing * 0.72 - 0.12;
    this.player.rotation.z = (targetX - this.player.position.x) * -0.075;
    this.playerShadow.position.x = this.player.position.x;
    this.playerShadow.material.opacity = 0.26 - Math.min(0.14, this.jumpHeight * 0.05);

    if (this.magnetTimer > 0) this.magnetTimer = Math.max(0, this.magnetTimer - delta);
    if (this.multiplierTimer > 0) this.multiplierTimer = Math.max(0, this.multiplierTimer - delta);
    if (this.boostTimer > 0) this.boostTimer = Math.max(0, this.boostTimer - delta);
  }

  updateObjects(delta) {
    const movement = this.speed * delta;
    for (let index = this.activeObjects.length - 1; index >= 0; index -= 1) {
      const object = this.activeObjects[index];
      object.z += movement;
      object.group.position.z = object.z;

      if (object.kind === 'coin') {
        object.group.rotation.y += delta * 2.25;
        const magnetLevel = this.options.upgrades?.magnet || 0;
        if (this.magnetTimer > 0 && object.z > -20 && Math.abs(object.group.position.x - this.player.position.x) < 4.8 + magnetLevel * 1.15) {
          object.group.position.x += (this.player.position.x - object.group.position.x) * Math.min(1, delta * (4.5 + (this.options.upgrades?.magnet || 0)));
          object.group.position.y += (1.25 + this.jumpHeight - object.group.position.y) * Math.min(1, delta * 4);
        }
        const laneMatch = Math.abs(object.group.position.x - this.player.position.x) < 1.05;
        const depthMatch = Math.abs(object.z - PLAYER_Z) < 1.55;
        const heightMatch = Math.abs(object.group.position.y - (1.1 + this.jumpHeight)) < 1.62;
        if (laneMatch && depthMatch && heightMatch) {
          this.collectObject(object, index);
          continue;
        }
      } else if (object.kind === 'powerup') {
        object.group.rotation.y += delta * 1.55;
        object.group.position.y = 1.35 + Math.sin(this.elapsed * 3 + object.spin) * 0.13;
        if (Math.abs(object.group.position.x - this.player.position.x) < 1.15 && Math.abs(object.z - PLAYER_Z) < 1.5) {
          this.collectObject(object, index);
          continue;
        }
      } else {
        const laneMatch = Math.abs(LANES[object.lane] - this.player.position.x) < 1.08;
        const depthMatch = Math.abs(object.z - PLAYER_Z) < (object.type === 'train' ? 4.7 : 1.25);
        if (laneMatch && depthMatch) {
          let collided = true;
          if (object.type === 'barrier' || object.type === 'crate') collided = this.jumpHeight < 0.78;
          if (object.type === 'beam') collided = this.slideTimer < 0.05;
          if (collided) {
            if (this.handleCollision()) return;
          }
          this.recycleGroup(object.group);
          this.activeObjects.splice(index, 1);
          continue;
        }
      }

      if (object.z > 24) {
        this.recycleGroup(object.group);
        this.activeObjects.splice(index, 1);
      }
    }
  }

  updateParticles(delta) {
    for (let index = this.particles.length - 1; index >= 0; index -= 1) {
      const particle = this.particles[index];
      particle.life -= delta;
      particle.mesh.position.addScaledVector(particle.velocity, delta);
      particle.velocity.y -= 7 * delta;
      particle.mesh.material.opacity = clamp(particle.life / particle.maxLife, 0, 1);
      if (particle.life <= 0) {
        this.scene.remove(particle.mesh);
        particle.mesh.geometry.dispose();
        particle.mesh.material.dispose();
        this.particles.splice(index, 1);
      }
    }
  }

  updateCamera(delta) {
    const x = this.player.position.x * 0.22;
    this.camera.position.x += (x - this.camera.position.x) * Math.min(1, delta * 2.6);
    const y = 6.2 + this.jumpHeight * 0.16;
    this.camera.position.y += (y - this.camera.position.y) * Math.min(1, delta * 2.3);
    const targetFov = this.boostTimer > 0 ? 63 : 57;
    if (Math.abs(this.camera.fov - targetFov) > 0.2) {
      this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, delta * 3.5);
      this.camera.updateProjectionMatrix();
    }
    this.camera.lookAt(this.player.position.x * 0.1, 1.05 + this.jumpHeight * 0.18, -12);
  }

  tick(now) {
    if (this.disposed) return;
    this.frameId = requestAnimationFrame(this.tick);
    const delta = clamp((now - this.lastFrame) / 1000, 0, 0.045) || 0.016;
    this.lastFrame = now;
    this.worldTime += delta;

    if (this.mode === 'playing' && !this.paused) {
      this.elapsed += delta;
      this.speed = Math.min(33, 15 + this.distance * 0.027) * (this.boostTimer > 0 ? 1.36 : 1);
      this.distance += this.speed * delta;
      this.score += this.speed * delta * (this.multiplierTimer > 0 ? 20 : 10);
      this.spawnTimer -= delta;
      if (this.spawnTimer <= 0) {
        this.spawnWave();
        const intensity = clamp(this.distance / 720, 0, 1);
        this.spawnTimer = 1.7 - intensity * 0.43 + Math.random() * 0.22;
      }
      this.updateWorld(delta);
      this.updatePlayer(delta);
      this.updateObjects(delta);
      this.updateTheme();
      if (now - this.lastHudUpdate > 90) {
        this.callbacks.onHud?.(this.getHud());
        this.lastHudUpdate = now;
      }
    } else if (this.mode === 'menu' || this.mode === 'tutorial') {
      this.speed = 1.7;
      this.updateWorld(delta * 0.5);
      if (this.player) {
        this.player.position.y = Math.sin(this.worldTime * 1.35) * 0.035;
        this.characterPivot.position.y = 1.0 + Math.sin(this.worldTime * 7.5) * 0.025;
        const stride = Math.sin(this.worldTime * 7.5) * 0.24;
        this.legPivots[0].rotation.x = stride;
        this.legPivots[1].rotation.x = -stride;
        this.armPivots[0].rotation.x = -stride * 0.75;
        this.armPivots[1].rotation.x = stride * 0.75;
      }
    } else if (this.mode === 'over') {
      this.gameOverTime += delta;
      this.updateWorld(delta * 0.12);
      this.characterPivot.rotation.x += (0.55 - this.characterPivot.rotation.x) * Math.min(1, delta * 2.6);
      this.characterPivot.rotation.z += (0.28 - this.characterPivot.rotation.z) * Math.min(1, delta * 2.0);
    } else if (this.mode === 'playing' && this.paused) {
      // Freeze all world and player simulation while the pause overlay is visible.
    }

    this.updateParticles(delta);
    this.updateCamera(delta);
    this.renderer.render(this.scene, this.camera);
  }

  dispose() {
    this.disposed = true;
    if (this.frameId) cancelAnimationFrame(this.frameId);
    window.removeEventListener('resize', this.handleResize);
    this.clearRunObjects();
    for (const groups of this.objectPools.values()) {
      groups.forEach((group) => this.removeGroup(group));
    }
    this.objectPools.clear();
    if (this.scene) {
      const materials = new Set();
      this.scene.traverse((child) => {
        if (child.geometry) child.geometry.dispose();
        if (child.material) {
          const list = Array.isArray(child.material) ? child.material : [child.material];
          list.forEach((material) => materials.add(material));
        }
      });
      materials.forEach((material) => material.dispose());
    }
    this.renderer?.dispose();
  }
}
