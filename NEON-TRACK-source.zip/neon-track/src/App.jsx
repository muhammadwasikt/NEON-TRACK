import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUp, AudioLines, Award, Check, ChevronRight,
  Coins, Gamepad2, Pause, Play, RotateCcw, Settings2, Shield, ShoppingBag,
  Sparkles, Trophy, Volume2, VolumeX, X, Zap,
} from 'lucide-react';
import { NeonTrackEngine } from './game/NeonTrackEngine.js';
import { AudioEngine } from './game/audio.js';

const SAVE_KEY = 'neon-track-save-v1';
const CHARACTERS = [
  { id: 0, name: 'RIFT', role: 'STREET RUNNER', price: 0, color: '#ff7845', description: 'The original night-shift runner.' },
  { id: 1, name: 'NOVA', role: 'NEON DRIFTER', price: 250, color: '#41cce9', description: 'Built for the midnight express.' },
  { id: 2, name: 'KAIRO', role: 'SKYLINE GHOST', price: 600, color: '#a48bff', description: 'A legend above the city.' },
];
const MISSIONS = [
  { id: 'distance', title: 'NIGHT SHIFT', detail: 'Travel 500 metres in a single run', target: 500, reward: 80 },
  { id: 'coins', title: 'POCKET CHANGE', detail: 'Collect 30 coins across your runs', target: 30, reward: 100 },
  { id: 'score', title: 'NO LIMITS', detail: 'Reach 2,000 points in a single run', target: 2000, reward: 120 },
];
const DEFAULT_SAVE = {
  bestScore: 0, bestDistance: 0, coins: 0, totalCoins: 0,
  unlocked: [0], selected: 0, quality: 'auto', sfx: true, music: false,
  tutorialSeen: false, missionProgress: { distance: 0, coins: 0, score: 0 },
  completedMissions: [], upgrades: { magnet: 0, shield: 0, multiplier: 0 },
};

function number(value) { return Math.floor(value || 0).toLocaleString('en-US'); }

function loadSave() {
  try {
    const stored = localStorage.getItem(SAVE_KEY);
    if (!stored) return structuredClone(DEFAULT_SAVE);
    const parsed = JSON.parse(stored);
    const safe = { ...structuredClone(DEFAULT_SAVE), ...parsed };
    safe.unlocked = Array.isArray(safe.unlocked) ? safe.unlocked.filter((id) => [0, 1, 2].includes(id)) : [0];
    if (!safe.unlocked.includes(0)) safe.unlocked.unshift(0);
    safe.selected = safe.unlocked.includes(safe.selected) ? safe.selected : 0;
    safe.coins = Math.max(0, Number(safe.coins) || 0);
    safe.bestScore = Math.max(0, Number(safe.bestScore) || 0);
    safe.bestDistance = Math.max(0, Number(safe.bestDistance) || 0);
    safe.totalCoins = Math.max(0, Number(safe.totalCoins) || 0);
    safe.missionProgress = { ...DEFAULT_SAVE.missionProgress, ...(safe.missionProgress || {}) };
    Object.keys(safe.missionProgress).forEach((key) => { safe.missionProgress[key] = Math.max(0, Number(safe.missionProgress[key]) || 0); });
    safe.completedMissions = Array.isArray(safe.completedMissions) ? safe.completedMissions.filter((id) => MISSIONS.some((mission) => mission.id === id)) : [];
    safe.upgrades = { ...DEFAULT_SAVE.upgrades, ...(safe.upgrades || {}) };
    Object.keys(safe.upgrades).forEach((key) => { safe.upgrades[key] = Math.min(3, Math.max(0, Math.floor(Number(safe.upgrades[key]) || 0))); });
    safe.quality = ['low', 'medium', 'high', 'auto'].includes(safe.quality) ? safe.quality : 'auto';
    safe.sfx = safe.sfx !== false;
    safe.music = safe.music === true;
    safe.tutorialSeen = safe.tutorialSeen === true;
    return safe;
  } catch {
    return structuredClone(DEFAULT_SAVE);
  }
}

function CharacterPortrait({ character, selected }) {
  return (
    <div className={`character-portrait ${selected ? 'portrait-selected' : ''}`} style={{ '--char-color': character.color }}>
      <div className="portrait-aura" />
      <div className="portrait-head"><i /></div>
      <div className="portrait-body"><i /></div>
      <div className="portrait-strap" />
      <span className="portrait-glint" />
    </div>
  );
}

export default function App() {
  const canvasRef = useRef(null);
  const engineRef = useRef(null);
  const audioRef = useRef(null);
  const saveRef = useRef(DEFAULT_SAVE);
  const [save, setSave] = useState(DEFAULT_SAVE);
  const [screen, setScreen] = useState('menu');
  const [panel, setPanel] = useState('');
  const [tutorialIndex, setTutorialIndex] = useState(0);
  const [hud, setHud] = useState({ score: 0, distance: 0, coins: 0, speed: 15, powerups: {}, active: '', theme: 'NEON METRO CITY' });
  const [smallScreen, setSmallScreen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [engineError, setEngineError] = useState('');

  const persist = useCallback((next) => {
    saveRef.current = next;
    setSave(next);
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(next)); } catch { /* storage can be disabled by the browser */ }
    engineRef.current?.setOptions({
      quality: next.quality,
      character: next.selected,
      upgrades: next.upgrades,
    });
    audioRef.current?.setEffects(next.sfx);
    audioRef.current?.setMusic(next.music);
  }, []);

  const handleHud = useCallback((next) => setHud(next), []);

  const handleGameOver = useCallback((result) => {
    const previous = saveRef.current;
    const progress = { ...previous.missionProgress };
    progress.distance = Math.max(progress.distance || 0, result.distance);
    progress.coins = (progress.coins || 0) + result.coins;
    progress.score = Math.max(progress.score || 0, result.score);
    const completed = [...previous.completedMissions];
    let reward = 0;
    let missionsCompleted = 0;
    MISSIONS.forEach((mission) => {
      if (!completed.includes(mission.id) && progress[mission.id] >= mission.target) {
        completed.push(mission.id);
        reward += mission.reward;
        missionsCompleted += 1;
      }
    });
    const next = {
      ...previous,
      bestScore: Math.max(previous.bestScore, result.score),
      bestDistance: Math.max(previous.bestDistance, result.distance),
      coins: previous.coins + result.coins + reward,
      totalCoins: previous.totalCoins + result.coins,
      missionProgress: progress,
      completedMissions: completed,
    };
    persist(next);
    setHud((current) => ({ ...current, ...result, powerups: current.powerups || {} }));
    setScreen('over');
    if (missionsCompleted) audioRef.current?.play('mission');
  }, [persist]);

  useEffect(() => {
    const loaded = loadSave();
    saveRef.current = loaded;
    setSave(loaded);
    const audio = new AudioEngine();
    audioRef.current = audio;
    audio.setEffects(loaded.sfx);
    const engine = new NeonTrackEngine(canvasRef.current, {
      onHud: handleHud,
      onGameOver: handleGameOver,
      onSound: (name) => audioRef.current?.play(name),
      onTheme: (theme) => setHud((current) => ({ ...current, theme })),
    });
    engineRef.current = engine;
    engine.setOptions({ quality: loaded.quality, character: loaded.selected, upgrades: loaded.upgrades });
    try {
      engine.init();
      setEngineError('');
    } catch {
      setEngineError('This browser or device could not start WebGL 3D rendering. Try an updated Chrome, Edge or Safari browser with hardware acceleration enabled.');
      engine.dispose();
    }
    return () => {
      engine.dispose();
      audio.dispose();
      engineRef.current = null;
      audioRef.current = null;
    };
  }, [handleGameOver, handleHud]);

  useEffect(() => {
    const resize = () => setSmallScreen(window.innerWidth < 720);
    resize();
    window.addEventListener('resize', resize, { passive: true });
    return () => window.removeEventListener('resize', resize);
  }, []);

  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && screen === 'playing') {
        engineRef.current?.pause();
        setScreen('paused');
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [screen]);

  const playSound = useCallback((name = 'click') => audioRef.current?.play(name), []);

  const beginRun = useCallback(() => {
    audioRef.current?.setMusic(saveRef.current.music);
    playSound();
    setPanel('');
    if (!saveRef.current.tutorialSeen) {
      setTutorialIndex(0);
      setScreen('tutorial');
      return;
    }
    engineRef.current?.startNewRun();
    setScreen('playing');
  }, [playSound]);

  const finishTutorial = useCallback(() => {
    persist({ ...saveRef.current, tutorialSeen: true });
    engineRef.current?.startNewRun();
    setScreen('playing');
    setPanel('');
  }, [persist]);

  const pauseRun = useCallback(() => {
    engineRef.current?.pause();
    setScreen('paused');
    playSound();
  }, [playSound]);

  const resumeRun = useCallback(() => {
    engineRef.current?.resume();
    setScreen('playing');
    playSound();
  }, [playSound]);

  const restartRun = useCallback(() => {
    engineRef.current?.startNewRun();
    setHud({ score: 0, distance: 0, coins: 0, speed: 15, powerups: {}, active: '', theme: 'NEON METRO CITY' });
    setScreen('playing');
    playSound();
  }, [playSound]);

  const action = useCallback((name) => {
    const engine = engineRef.current;
    if (name === 'left') engine?.moveLane(-1);
    if (name === 'right') engine?.moveLane(1);
    if (name === 'jump') engine?.jump();
    if (name === 'slide') engine?.slide();
  }, []);

  useEffect(() => {
    const keydown = (event) => {
      const key = event.key.toLowerCase();
      if (['arrowleft', 'arrowright', 'arrowup', 'arrowdown', ' '].includes(key)) event.preventDefault();
      if (screen === 'playing') {
        if (key === 'arrowleft' || key === 'a') action('left');
        if (key === 'arrowright' || key === 'd') action('right');
        if (key === 'arrowup' || key === 'w' || key === ' ') action('jump');
        if (key === 'arrowdown' || key === 's') action('slide');
        if (key === 'escape') pauseRun();
      } else if (key === 'escape') {
        if (panel) setPanel('');
        else if (screen === 'paused') resumeRun();
      }
    };
    window.addEventListener('keydown', keydown, { passive: false });
    return () => window.removeEventListener('keydown', keydown);
  }, [action, panel, pauseRun, resumeRun, screen]);

  useEffect(() => {
    if (screen !== 'playing') return undefined;
    let startX = 0;
    let startY = 0;
    const target = canvasRef.current;
    const pointerDown = (event) => {
      startX = event.clientX;
      startY = event.clientY;
    };
    const pointerUp = (event) => {
      const dx = event.clientX - startX;
      const dy = event.clientY - startY;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 25) return;
      if (Math.abs(dx) > Math.abs(dy)) action(dx > 0 ? 'right' : 'left');
      else action(dy < 0 ? 'jump' : 'slide');
    };
    target?.addEventListener('pointerdown', pointerDown, { passive: true });
    target?.addEventListener('pointerup', pointerUp, { passive: true });
    return () => {
      target?.removeEventListener('pointerdown', pointerDown);
      target?.removeEventListener('pointerup', pointerUp);
    };
  }, [action, screen]);

  const openPanel = (name) => { playSound(); setPanel(name); };

  const buyCharacter = (character) => {
    const current = saveRef.current;
    if (current.unlocked.includes(character.id)) {
      persist({ ...current, selected: character.id });
      playSound('click');
      return;
    }
    if (current.coins < character.price) return;
    persist({ ...current, coins: current.coins - character.price, unlocked: [...current.unlocked, character.id], selected: character.id });
    playSound('power');
  };

  const buyUpgrade = (type) => {
    const current = saveRef.current;
    const level = current.upgrades[type] || 0;
    const costs = [180, 320, 520];
    const price = costs[level];
    if (level >= 3 || current.coins < price) return;
    persist({
      ...current,
      coins: current.coins - price,
      upgrades: { ...current.upgrades, [type]: level + 1 },
    });
    playSound('power');
  };

  const toggleSetting = (key) => {
    const current = saveRef.current;
    persist({ ...current, [key]: !current[key] });
    playSound('click');
  };

  const changeQuality = (quality) => {
    persist({ ...saveRef.current, quality });
    playSound('click');
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
      else await document.exitFullscreen();
    } catch { /* fullscreen is optional and may be denied */ }
  };

  useEffect(() => {
    const changed = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', changed);
    return () => document.removeEventListener('fullscreenchange', changed);
  }, []);

  const selectedCharacter = CHARACTERS.find((character) => character.id === save.selected) || CHARACTERS[0];
  const tutorialSteps = [
    { icon: <><ArrowLeft size={25}/><ArrowRight size={25}/></>, title: 'SWITCH LANES', text: 'Swipe left or right, or use A / D to move across the three tracks.' },
    { icon: <ArrowUp size={32}/>, title: 'JUMP OVER HAZARDS', text: 'Swipe up, press W / Space, or tap the jump control to clear barriers.' },
    { icon: <ArrowDown size={32}/>, title: 'SLIDE UNDERNEATH', text: 'Swipe down or press S to get beneath low beams and overhead signs.' },
    { icon: <Coins size={32}/>, title: 'COLLECT THE GLOW', text: 'Grab coins and power cores. Always look for a clear lane through the traffic.' },
  ];

  return (
    <main className="nt-app">
      <canvas ref={canvasRef} className="nt-world" aria-label="NEON TRACK three-dimensional railway game world" />
      <div className="nt-vignette" />
      {engineError && <div className="nt-webgl-error"><strong>3D RENDERING UNAVAILABLE</strong><p>{engineError}</p></div>}

      <header className="nt-topbar">
        <div className="nt-brand"><span className="nt-brand-mark">N</span><span>NEON<span className="nt-brand-soft">TRACK</span></span></div>
        <div className="nt-top-stats">
          <span><Trophy size={14}/>{number(save.bestScore)}</span>
          <span><Coins size={15}/>{number(save.coins)}</span>
        </div>
        <button className="nt-icon-button" onClick={() => openPanel('settings')} aria-label="Open settings"><Settings2 size={19}/></button>
      </header>

      {screen === 'menu' && (
        <section className="nt-menu-screen">
          <div className="nt-menu-copy">
            <div className="nt-eyebrow"><i className="nt-live-dot"/> THE CITY NEVER SLEEPS</div>
            <h1>NEON<br/><em>TRACK</em></h1>
            <p className="nt-tagline">Every second counts.<br/>Every run is different.</p>
            <div className="nt-menu-actions">
              <button className="nt-primary-button" onClick={beginRun}><Play size={18} fill="currentColor"/> START RUN <ChevronRight size={19}/></button>
              <button className="nt-secondary-button" onClick={() => openPanel('characters')}><span className="nt-character-mini" style={{ '--character-color': selectedCharacter.color }}/>{selectedCharacter.name} <ChevronRight size={16}/></button>
            </div>
            <div className="nt-best-line"><span>PERSONAL BEST</span><strong>{number(save.bestScore)}</strong><i>·</i><span>{number(save.bestDistance)} M</span></div>
          </div>
          <div className="nt-menu-footer">
            <button onClick={() => openPanel('missions')}><Award size={17}/> MISSIONS</button>
            <button onClick={() => openPanel('shop')}><ShoppingBag size={17}/> THE GARAGE</button>
            <button onClick={() => openPanel('settings')}><Settings2 size={17}/> SETTINGS</button>
            <div className="nt-control-hint"><span>← →</span> SWITCH <span>↑</span> JUMP <span>↓</span> SLIDE</div>
          </div>
        </section>
      )}

      {screen === 'playing' && (
        <section className="nt-hud">
          <div className="nt-hud-row">
            <div className="nt-hud-score"><span>SCORE</span><strong>{number(hud.score)}</strong></div>
            <div className="nt-hud-coin"><Coins size={18}/><strong>{number(hud.coins)}</strong></div>
            <button className="nt-pause-button" onClick={pauseRun} aria-label="Pause game"><Pause size={18} fill="currentColor"/></button>
          </div>
          <div className="nt-distance"><span>{number(hud.distance)} M</span><div><i style={{ width: `${Math.min(100, (hud.distance / 1200) * 100)}%` }}/></div><span>{hud.theme || 'RUN'}</span></div>
          {hud.active && <div className="nt-active-power"><Sparkles size={14}/>{hud.active}<span>{hud.powerups?.shield ? `${hud.powerups.shield} CHARGE` : `${Math.ceil(Math.max(hud.powerups?.magnet || 0, hud.powerups?.multiplier || 0, hud.powerups?.boost || 0))}s`}</span></div>}
          <div className="nt-touch-controls">
            <button onPointerDown={(event) => { event.preventDefault(); action('left'); }} aria-label="Move left"><ArrowLeft/></button>
            <div>
              <button onPointerDown={(event) => { event.preventDefault(); action('jump'); }} aria-label="Jump"><ArrowUp/></button>
              <button onPointerDown={(event) => { event.preventDefault(); action('slide'); }} aria-label="Slide"><ArrowDown/></button>
            </div>
            <button onPointerDown={(event) => { event.preventDefault(); action('right'); }} aria-label="Move right"><ArrowRight/></button>
          </div>
          {smallScreen && <div className="nt-mobile-hint">SWIPE TO MOVE · TAP BUTTONS TO ACT</div>}
        </section>
      )}

      {screen === 'tutorial' && (
        <div className="nt-modal-backdrop">
          <section className="nt-dialog nt-tutorial">
            <div className="nt-dialog-kicker">FIRST RUN // QUICK BRIEF</div>
            <div className="nt-tutorial-icon">{tutorialSteps[tutorialIndex].icon}</div>
            <h2>{tutorialSteps[tutorialIndex].title}</h2>
            <p>{tutorialSteps[tutorialIndex].text}</p>
            <div className="nt-dots">{tutorialSteps.map((step, index) => <i key={step.title} className={index === tutorialIndex ? 'active' : ''}/>)}</div>
            <div className="nt-dialog-actions">
              <button className="nt-text-button" onClick={finishTutorial}>SKIP</button>
              <button className="nt-primary-button nt-small-primary" onClick={() => tutorialIndex < tutorialSteps.length - 1 ? setTutorialIndex(tutorialIndex + 1) : finishTutorial()}>{tutorialIndex < tutorialSteps.length - 1 ? 'NEXT' : "LET'S RUN"}<ChevronRight size={17}/></button>
            </div>
          </section>
        </div>
      )}

      {screen === 'paused' && (
        <div className="nt-modal-backdrop">
          <section className="nt-dialog">
            <div className="nt-dialog-kicker">RUN ON HOLD</div>
            <h2>TAKE A BREATHER.</h2>
            <p>The city can wait. Your run is safe.</p>
            <div className="nt-pause-stats"><div><span>SCORE</span><strong>{number(hud.score)}</strong></div><div><span>DISTANCE</span><strong>{number(hud.distance)} M</strong></div></div>
            <button className="nt-primary-button nt-full-button" onClick={resumeRun}><Play size={17} fill="currentColor"/> RESUME RUN</button>
            <div className="nt-dialog-actions"><button className="nt-text-button" onClick={restartRun}><RotateCcw size={14}/> RESTART</button><button className="nt-text-button" onClick={() => setPanel('settings')}><Settings2 size={14}/> SETTINGS</button><button className="nt-text-button" onClick={() => { engineRef.current?.showMenu(); setScreen('menu'); }}>MAIN MENU</button></div>
          </section>
        </div>
      )}

      {screen === 'over' && (
        <div className="nt-modal-backdrop">
          <section className="nt-dialog nt-gameover">
            <div className="nt-gameover-stamp"><Trophy size={21}/><span>RUN COMPLETE</span></div>
            <h2>THE LINE<br/><em>ENDS HERE.</em></h2>
            {hud.score >= save.bestScore && hud.score > 0 && <div className="nt-new-record">✦ NEW PERSONAL BEST ✦</div>}
            <div className="nt-results-grid">
              <div className="nt-result-main"><span>FINAL SCORE</span><strong>{number(hud.score)}</strong></div>
              <div><span>DISTANCE</span><strong>{number(hud.distance)} M</strong></div>
              <div><span>COINS</span><strong>{number(hud.coins)}</strong></div>
              <div><span>BEST SCORE</span><strong>{number(save.bestScore)}</strong></div>
            </div>
            <button className="nt-primary-button nt-full-button" onClick={restartRun}><RotateCcw size={17}/> RUN IT BACK</button>
            <button className="nt-text-button nt-center-button" onClick={() => { engineRef.current?.showMenu(); setScreen('menu'); }}>BACK TO MAIN MENU</button>
          </section>
        </div>
      )}

      {panel && (
        <div className="nt-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setPanel(''); }}>
          <section className="nt-dialog nt-panel" role="dialog" aria-modal="true" aria-label={`${panel} panel`}>
            <div className="nt-panel-head">
              <div><div className="nt-dialog-kicker">NEON TRACK // {panel.toUpperCase()}</div><h2>{panel === 'characters' ? 'CHOOSE YOUR RUNNER' : panel === 'shop' ? 'THE GARAGE' : panel === 'missions' ? 'RUN OBJECTIVES' : 'GAME SETTINGS'}</h2></div>
              <button className="nt-close-button" onClick={() => setPanel('')} aria-label="Close panel"><X size={19}/></button>
            </div>

            {panel === 'characters' && (
              <div className="nt-character-list">
                {CHARACTERS.map((character) => {
                  const unlocked = save.unlocked.includes(character.id);
                  const selected = save.selected === character.id;
                  return (
                    <div className={`nt-character-card ${selected ? 'selected' : ''}`} key={character.id}>
                      <CharacterPortrait character={character} selected={selected}/>
                      <div className="nt-character-info"><span>{character.role}</span><strong>{character.name}</strong><small>{character.description}</small></div>
                      <button className={selected ? 'nt-selected-pill' : 'nt-buy-pill'} disabled={!unlocked && save.coins < character.price} onClick={() => buyCharacter(character)}>
                        {selected ? <><Check size={14}/> SELECTED</> : unlocked ? 'SELECT' : <><Coins size={13}/>{number(character.price)}</>}
                      </button>
                    </div>
                  );
                })}
                <p className="nt-panel-note">Your chosen runner appears in the live 3D world behind this panel.</p>
              </div>
            )}

            {panel === 'shop' && (
              <div className="nt-shop-list">
                {[
                  { id: 'magnet', name: 'MAGNET RANGE', description: 'Attract coins from further away and extend the effect.' },
                  { id: 'shield', name: 'SHIELD CAPACITY', description: 'Begin each run with one extra shield charge.' },
                  { id: 'multiplier', name: 'SCORE CORE', description: 'Extend the double-score power-up duration.' },
                ].map((item) => {
                  const level = save.upgrades[item.id] || 0;
                  const price = [180, 320, 520][level];
                  return (
                    <div className="nt-upgrade-card" key={item.id}>
                      <div className="nt-upgrade-icon">{item.id === 'shield' ? <Shield size={21}/> : <Zap size={21}/>}</div>
                      <div className="nt-upgrade-info"><strong>{item.name}</strong><small>{item.description}</small><div className="nt-level-bars">{[1, 2, 3].map((levelNumber) => <i key={levelNumber} className={levelNumber <= level ? 'filled' : ''}/>)}</div></div>
                      <button className="nt-buy-pill" disabled={level >= 3 || save.coins < price} onClick={() => buyUpgrade(item.id)}>{level >= 3 ? 'MAX' : <><Coins size={13}/>{number(price)}</>}</button>
                    </div>
                  );
                })}
                <p className="nt-panel-note">Upgrades are stored locally and apply automatically to future runs.</p>
              </div>
            )}

            {panel === 'missions' && (
              <div className="nt-mission-list">
                {MISSIONS.map((mission) => {
                  const done = save.completedMissions.includes(mission.id);
                  const progress = Math.min(1, (save.missionProgress[mission.id] || 0) / mission.target);
                  return (
                    <div className="nt-mission-card" key={mission.id}>
                      <div className="nt-mission-top"><div><span>{done ? 'COMPLETED' : 'OBJECTIVE'}</span><strong>{mission.title}</strong><small>{mission.detail}</small></div><div className="nt-reward"><Coins size={14}/>{mission.reward}</div></div>
                      <div className="nt-progress"><i style={{ width: `${progress * 100}%` }}/></div>
                      <div className="nt-mission-bottom"><span>{number(Math.min(mission.target, save.missionProgress[mission.id] || 0))} / {number(mission.target)}</span>{done && <b><Check size={13}/> REWARDED</b>}</div>
                    </div>
                  );
                })}
              </div>
            )}

            {panel === 'settings' && (
              <div className="nt-settings-list">
                <div className="nt-setting-row"><div><strong>SOUND EFFECTS</strong><small>Coins, jumps, impacts and power-ups</small></div><button className={`nt-toggle ${save.sfx ? 'on' : ''}`} onClick={() => toggleSetting('sfx')}>{save.sfx ? <Volume2 size={15}/> : <VolumeX size={15}/>} {save.sfx ? 'ON' : 'OFF'}</button></div>
                <div className="nt-setting-row"><div><strong>AMBIENT MUSIC</strong><small>Soft procedural synth atmosphere</small></div><button className={`nt-toggle ${save.music ? 'on' : ''}`} onClick={() => toggleSetting('music')}><AudioLines size={15}/>{save.music ? 'ON' : 'OFF'}</button></div>
                <div className="nt-setting-row nt-quality-row"><div><strong>GRAPHICS QUALITY</strong><small>Balance visual detail and performance</small></div><div className="nt-quality-options">{['low', 'medium', 'high', 'auto'].map((quality) => <button key={quality} className={save.quality === quality ? 'active' : ''} onClick={() => changeQuality(quality)}>{quality.toUpperCase()}</button>)}</div></div>
                <button className="nt-setting-full" onClick={toggleFullscreen}><Gamepad2 size={15}/>{isFullscreen ? 'EXIT FULLSCREEN' : 'ENTER FULLSCREEN'}</button>
                <p className="nt-panel-note">NEON TRACK saves progress in this browser. Clearing browser storage removes this local save.</p>
              </div>
            )}
          </section>
        </div>
      )}

      {screen === 'menu' && <div className="nt-build-mark"><span>3D ENDLESS RUNNER</span><i/> WEBGL EXPERIENCE</div>}
    </main>
  );
}
